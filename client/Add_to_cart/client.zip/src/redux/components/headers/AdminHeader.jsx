import React from 'react'

const AdminHeader = () => {
  return (
    <div>AdminHeader</div>
  )
}

export default AdminHeader