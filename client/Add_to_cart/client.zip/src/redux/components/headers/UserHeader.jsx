import React from 'react'

const UserHeader = () => {
  return (
    <div>UserHeader</div>
  )
}

export default UserHeader