import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import React, { useState } from 'react';

const Login = () => {
    const [user, setUser] = useState({ email: '', password: '' }); // Initialize user with email and password
    const navigate = useNavigate();

    const login = async (e) => {
        e.preventDefault();
        try {
            const userLogin = await axios.post("http://localhost:3001/v1/user/login", user);
            console.log(userLogin.data); // Log the response

            // Correctly store token and role in localStorage
            const token = userLogin.data.token; // Assuming the token is at this path
            const role = userLogin.data.user.role; // Assuming role is nested in user object

            if (token) {
                localStorage.setItem("token", token); // Store token
                localStorage.setItem("role", role); // Store role
            } else {
                console.error("No token received");
                return; // Exit if token is missing
            }

            // Navigate based on role
            if (role === "admin") {
                navigate("/dashboard");
            } else if (role === "user") {
                navigate("/home");
            } else {
                alert("You are an unknown person");
            }
        } catch (error) {
            console.error("Login failed:", error);
            alert("Login failed. Please check your credentials.");
        }
    };

    const userHandle = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    return (
        <>
            <input
                type="text"
                name='email'
                value={user.email}
                onChange={userHandle}
                placeholder="Email"
            />
            <input
                type="password" // Change to 'password' type for security
                name='password'
                value={user.password}
                onChange={userHandle}
                placeholder="Password"
            />
            <button onClick={login}>Login</button>
        </>
    );
};

export default Login;
