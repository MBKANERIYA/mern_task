import axios from "axios"
import React, { useEffect, useState } from 'react'

const Dashboard = () => {
    let [user, setUser] = useState([])

    let getUser = async () => {
        let get = await axios.get("http://localhost:3001/v1/user/recive")
        console.log(get.data.user);
        let users = get.data.user
        setUser(users)
    }

    useEffect(() => {
        getUser()
    }, [])
    return (
        <div className="app">
            {
                user.map((val,index) => (
                    <h1 key={index}>{val.email}</h1>
                ))
            }
            <h1>zdfgfhgjhj</h1>
        </div>
    )
}

export default Dashboard